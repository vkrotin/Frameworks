//
//  CRLog.h
//  CRLog
//
//  Created by  vkrotin on 27.09.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for CRLog.
FOUNDATION_EXPORT double CRLogVersionNumber;

//! Project version string for CRLog.
FOUNDATION_EXPORT const unsigned char CRLogVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CRLog/PublicHeader.h>


