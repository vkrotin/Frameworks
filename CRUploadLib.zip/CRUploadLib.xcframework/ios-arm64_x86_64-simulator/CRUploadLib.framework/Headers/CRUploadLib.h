//
//  CRUploadLib.h
//  CRUploadLib
//
//  Created by  vkrotin on 22.09.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for CRUploadLib.
FOUNDATION_EXPORT double CRUploadLibVersionNumber;
FOUNDATION_EXPORT const unsigned char CRUploadLibVersionString[];

